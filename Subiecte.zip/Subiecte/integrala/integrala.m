%{
Se considera functia: f:[0,1] -> R
f(x) = 1 / (x + 1)^2

Sa se genereze in mod aleator 1000 de puncte uniform distribuite
in patratul [0, 1] X [0, 1]

a) Aproximati valoare integralei: Integrala de la 0 la 1, din f(x)
b) Care este probabilitatea ca un punct sa fie generat deasupra graficului
functiei f stiind ca el are abscisa in intervalul [0, 0.5].
%}
function integrala()
%Subpunctul a)
  
f = @(x) 1 ./ (x + 1) .^ 2;
a = 0;
b = 1;
M = 1;

n = 1000;

%monte carlo 1
X = unifrnd(a, b, 1, n);
Y = unifrnd(0, M, 1, n);

integrala = (b - a) * M * mean(Y <= f(X));
integral(f, a, b); %pt verificare

disp(integrala);

%parte de plot
hold on;
%plot grafic f
t = linspace(0, 1, 1000);
plot(t, f(t), 'lineWidth', 3);

%plot punctele de deasupra
plot(X(f(X) < Y), Y(f(X) < Y), 'm*')
%plot punctele de jos
plot(X(f(X) > Y), Y(f(X) > Y), 'b*')


%Subpunctul b)
%probabilitatea simulata

%verificam punctele x care se afla intre 0 si 0.5
CPosibile = sum(X <= 0.5);
x = X(X <= 0.5);
y = Y(X <= 0.5);

CFavorabile = sum(y > f(x));

probabilitate = CFavorabile / CPosibile

%probabilitatea teoretica

CP = 1 * 0.5;
CF = CP - integral(f, 0, 0.5);
probabilitateTeoretica = CF / CP

endfunction


  
  
