%{
Consideram urmatorul experiment:
Se genereaza un vector w cu 6 numere alese 
aleator si independent conform distributiei uniforme
pe intervalul [0, 5]. Apoi, se aleg aleator cu returnare 3 numere
Y1, Y2, Y3, din w.

a) Generati 1000 de triplete de valori pentru Y1, Y2, Y3
Estimati valoare medie a produsului Y1 * Y2 * Y3
si probabilitatea ca Y1 + Y2 > Y3.

b) Afisati probabilitatea teoretica a evenimentului
ca exact 3 elemente din w sa apartina intervalului [2, 4]
%}


%subpunctul a)
nr_simulari = 1000;
w = unifrnd(0, 5, 1, 6);

count_produs = 0;
count_conditie = 0;
for i = 1 : nr_simulari
  y = randsample(w, 3, replacement = true);
  count_produs += (y(1) * y(2) * y(3));
  
  if y(1) + y(2) > y(3)
    count_conditie++;
  endif
endfor

valoareMedie = count_produs / nr_simulari
probabilitateConditie = count_conditie / nr_simulari

%subpunctul b)
probabilitate = unifcdf(4, 0, 5) - unifcdf(2, 0, 5);
PTeoretica = binopdf(3, length(w), probabilitate)
