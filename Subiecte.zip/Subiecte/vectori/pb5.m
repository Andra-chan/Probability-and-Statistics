%{
Consideram urmatorul experiment:
Se genereaza un vector v cu 5 numere alese aleator
si independent conform distributiei uniforme
pe intervalul [0, 10]. Apoi se aleg aleator fara returnare
2 numere X1 si X2 din v

a) Generati 100 de perechi de valori pentru X1 si X2,
apoi estimati valoare medie a sumei X1 + X2 si 
probabilitatea ca |X1 - X2| > 2

b) Afisati probabilitatea teoretica a evenimentului 
K: exact doua elemente din v sa apartina intervalului [5, 8]. 

%}

%subpunctul a)

v = unifrnd(0, 10, 1, 5);
nr_simulari = 1000;

count_suma = 0;
count_cond = 0;

for i = 1 : nr_simulari
  x = randsample(v, 2);
  
  count_suma += x(1) + x(2);
  
  if abs(x(1) - x(2)) > 2
    count_cond++;
  endif
endfor

valoare_medie_suma = count_suma / nr_simulari
probabilitate_conditie = count_cond / nr_simulari

%subpunctul b)
probabilitate = unifcdf(8, 0, 10) - unifcdf(5, 0, 10);
probabilitatea_teoretica = binopdf(2, length(v), probabilitate)