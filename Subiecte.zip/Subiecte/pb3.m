%{
3) Fie X ?i Y dou? variabile aleatoare independente av�nd distribu?iile:

X ~ (-1,    4) 
    (0.5, 0.5)    
?i 
Y ~ Unif[-1,4]. 
Fie U = X^3 � Y^3.

a) Genera?i 500 de valori pentru U ?i reprezenta?i 
grafic histograma corespunz?toare av�nd 20 clase.
	
b) Estima?i: P(U<0), valoarea medie ?i varian?a lui U.
	
c) C�t este valoarea medie (teoretic?) a lui X^3?
%}

%subpunctul a)
nr_simulari = 500;

nr = [-1, 4];
p = [0.5, 0.5];
x = randsample(nr, nr_simulari, replacement = true, p);
y = unifrnd(-1, 4, 1, nr_simulari);

u = x .^ 3 - y .^ 3;

hist(u, 20)

%subpunctul b)
P = sum(u < 0) / nr_simulari
valoarea_medie = mean(u)
varianta = std(u)^2

%subpunctul c)
medieTeoretica = sum(nr .^ 3)/length(nr)