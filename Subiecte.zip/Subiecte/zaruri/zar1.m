%{
Se arunca doua zaruri pana cand se obtine o dubla.
Fie x numarul de aruncari fara succes.
Simulati de 1000 de ori experimentul.

a) Estimati probabilitatea evenimentelor 
  A: "x mai mare ca 3"
  B: "x apartine {5, 6, ..., 10}"
  C: "x apartine multimii {5, 6, ..., 10}" stiind ca x > 3
  
b) Afisati probabilitatea teoretica a evenimentului B 
%}

%Subpunctul a)
nr_simulari = 1000;

%probabilitatea ca atunci cand arunci doua zaruri sa ai o dubla 
cazuri_posibile = 6^2;
cazuri_favorabile = 6;
probabilitateDubla = cazuri_favorabile / cazuri_posibile;

x = geornd(probabilitateDubla, 1, nr_simulari);

PA = mean(x > 3)
PB = mean (x >= 5 & x <= 10)
xc = x(x > 3);
PC = mean(xc >= 5 & xc <= 10)

%Subpunctul c
probabilitateC = sum(geopdf(5:10, probabilitateDubla))