%{
2) Pe intervalul [-2,5] s? se reprezinte grafic 
(�n dou? ferestre distincte) func?ia de densitate, 
respectiv func?ia de reparti?ie a unei variabile aleatoare X~Exp(2). 
Apoi, folosind simul?ri, s? se estimeze:
 a) valoarea medie E(X) ?i abaterea standard Std(X); 
 b) probabilitatea P(X > 0.7); 
 aceast? probabilitate estimat? s? se compare cu 
 probabilitatea teoretic? corespunz?toare cu ajutorul func?iei 
 de reparti?ie (a distribu?iei Exp(2)) ?i comenzi specifice Octave.
%}

close all;

%introducere
lambda = 2;

t = linspace(-2, 5, 2000);
%functia de densitate a unei variabile aleatoare X ~Exp(2)
figure(1);
plot(t, exppdf(t, 1/lambda), 'lineWidth', 3); 

%functia de repartitie a unei variabile aleatoare X ~Exp(2)
figure(2);
plot(t, expcdf(t, 1/lambda), 'lineWidth', 3, 'color', 'r');

%subpunctul a)
nr_simulari = 1000;

x = exprnd(1/lambda, 1, nr_simulari);
valoareMedie = mean(x)
abatereStandard = std(x)

%subpunctul b)
CF = sum(x > 0.7);
CP = nr_simulari;

P = CF / CP

PTeoretica = 1 - expcdf(0.7, 1/lambda)
