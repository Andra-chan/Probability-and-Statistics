%{
Intr-o urna sunt 4 bile galbene, 5 bile negre, 2 bile albe si 3 bile albastre.
Se extrag aleator:
a) cu returnare
b) fara returnare
4 bile din urna.

Estimati prin simulari pentru cazurile a), respectiv b) probabilitatile evenimentelor:
  A: "S-a extras cel mult o bila alba"
  B: "Nu s-a extras nicio bila galbena"
  C: "S-au extras cel putin 2 bile negre"
%}
nr_simulari = 1000;

galbene = ones(1, 4) * 'g';
negre = ones(1, 5) * 'n';
albe = ones(1, 2) * 'w';
albastre = ones(1, 3) * 'a';

urna = [galbene, negre, albe, albastre];

disp('subpunctul a');
countA = 0;
countB = 0;
countC = 0;

for i = 1 : nr_simulari
  x = randsample(urna, 4, replacement = true);
  if sum(x == 'w') <= 1
    countA++;
  endif
  
  if !any(x == 'g')
    countB++;
  endif
  
  if sum(x == 'n') >= 2
    countC++;
  endif
endfor

PA = countA / nr_simulari
PB = countB / nr_simulari
PC = countC / nr_simulari

%Subpunctul b)
disp('subpunctul b');

countA = 0;
countB = 0;
countC = 0;

for i = 1 : nr_simulari
  x = randsample(urna, 4, replacement = false);
  if sum(x == 'w') <= 1
    countA++;
  endif
  
  if !any(x == 'g')
    countB++;
  endif
  
  if sum(x == 'n') >= 2
    countC++;
  endif
endfor

PA = countA / nr_simulari
PB = countB / nr_simulari
PC = countC / nr_simulari
