%{ 
Consider?m urm?torul experiment: 
�ntr-o urn? sunt 10 bile ro?ii, 
5  bile negre ?i 5 bile albe. 
Se extrag aleator f?r? returnare 3 bile din urn?.

	
a) Estima?i, folosind comenzi Octave, probabilitatea evenimentelor:
	A: bilele au aceea?i culoare,
  B: cele 3 bile sunt de trei culori distincte; 
  ?: bilele nu au aceea?i culoare.
	
b) Afi?a?i probabilitatea teoretic? pentru P(A), P(B) ?i P(?).
%}

function pb1()
  %rosie = 1
  %negru = 2
  %alb = 3
  
  rosii = ones(1, 10);
  negre = ones(1, 5) * 2;
  albe = ones(1, 5) * 3;
  urna = [rosii, negre, albe];
  
  nr_simulari = 1000;
  
  %subpunctul a)
  count_A = 0;
  count_B = 0;
  
  for i = 1 : nr_simulari
      x = randsample(urna, 3);
      if length(unique(x)) == 1
        count_A++;
      endif
      
      if length(unique(x)) == 3
        count_B++;
      endif
  endfor
  
  PA = count_A / nr_simulari
  PB = count_B / nr_simulari
  PNotA = 1 - PA
  
  %subpunctul b)
  
  count_A = 0;
  count_B = 0;
  count_posibile = 0;

  for i = 1 : length(urna)
    for j = 1 : length(urna)
      for k = 1 : length(urna)
        if length(unique([i, j, k])) == 3
          count_posibile++;
          if length(unique([urna(i), urna(j), urna(k)])) == 1
            count_A++;
          endif
          
          if length(unique([urna(i), urna(j), urna(k)])) == 3
            count_B++;
          endif
        endif
      endfor
    endfor
  endfor
  
  PATeoretic = count_A / count_posibile
  PBTeoretic = count_B / count_posibile
  PNotATeoretic = 1 - PATeoretic
endfunction