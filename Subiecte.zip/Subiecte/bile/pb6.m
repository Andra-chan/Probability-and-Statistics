%{
Intr-o urna sunt 7 bile albe, 6 bile verzi si 5 bile rosii.
Se extrag in mod aleator fara returnare 3 bile.

a) Sa se estimeze folosind functii din octave probabilitatea ca:
  A. "Toate cele 3 bile sa fie verzi"
  B. "Toate bilele au culori diferite"
  C. "Cel mult doua bile sa fie albe"

b) Care este probabilitatea (teoretica) sa fie extrasa cel putin o bila verde
stiind ca prima bila extrasa a fost alba?
%}

%subpunctul a)

%albe = 1
%verzi = 2
%rosu = 3
albe = ones(1, 7) * 1;
verzi = ones(1, 6) * 2;
rosii = ones(1, 5) * 3;

urna = [albe, verzi, rosii];

nr_simulari = 1000;

countA = 0;
countB = 0;
countC = 0;

for i = 1 : nr_simulari
  x = randsample(urna, 3);
  if all(x == 2)
    countA++;
  endif
  
  if length(unique([x(1), x(2), x(3)])) == 3
    countB++;
  endif
  
  if !all(x == 1)
    countC++;
  endif
endfor

PA = countA / nr_simulari
PB = countB / nr_simulari
PC  =countC / nr_simulari

%subpunctul b)
CPosibile = 0;
CFavorabile = 0;

for i = 1 : length(urna)
  for j = 1 : length(urna)
    for k = 1 : length(urna)
      if (length(unique([i, j, k])) == 3 && urna(i) == 1)
        CPosibile++;
        if (urna(j) == 2 || urna(k) == 2)
          CFavorabile++;
        endif
      endif
    endfor
  endfor
endfor

probabilitate = CFavorabile / CPosibile
