%{
Intr-o urna sunt:
25 de bile numerotate cu 1,
10 bile numerotate cu 2,
15 bile numerotate cu 3,
15 bile numerotate cu 4.

Se efectueaza 10 extrageri cu returnare si se noteaza cu X
media aritmetica a numerelor extrase.

a) Afisati probabilitatea teoretica pentru ca exact 6 numerele
din cele 10 extrase sa fie impare.
b) Simulati 1000 de astfel de extrageri si estimati probabilitatea
ca suma numerelor de pe bilele extrase sa fie mai mare decat 20
si mai mica decat 30
c) Estimati valoarea medie a lui X folosind simularile de la subpunctu b)

%}
function pb8()

  bile1 = ones(1, 25);
  bile2 = ones(1, 10) * 2;
  bile3 = ones(1, 15) * 3;
  bile4 = ones(1, 15) * 4;
  
  urna = [bile1, bile2, bile3, bile4];
 
  %Subpunctul a)
  probabilitate = (25 + 15) / (25 + 10 + 15 + 15);
  probabilitateTeoretica = binopdf(6, 10, probabilitate)
  
  %Subpunctul b)
  nr_simulari = 1000;
  
  count = 0;
  medie = [];
  for i = 1 : nr_simulari
    x = randsample(urna, 10, replacement = true);
    suma = sum(x);
    if (suma > 20 && suma < 30)
      count++;
    endif
    medie = [medie, mean(x)];
  endfor
  
  probabilitateB = count / nr_simulari
  
  %Subpunctul c)
  valoareMedieX = mean(medie)

endfunction