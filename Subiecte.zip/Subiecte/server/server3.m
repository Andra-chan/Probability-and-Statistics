%{
Un email este trimis catre un server S1.
S1 processeaza un email in t1 secunde unde t1 e |y|, 
iar y are distributia normala cu parametrii m = 1 secunda
sigma = 1 secunda.
Daca au trecut 2 secunde, iar emailul nu a fost procesat
de serverul S1 pana in acest moment, atunci emailul
este redirectionat instant catre un al doilea server S2, 
care proceseaza un email in t2 secunde, unde t2 are distributia
exponentiala cu media 2 secunde.

a) Afisati probabilitatea teoretica pentru ca emailul sa fie procesat
in cel mult 1,5 secunde.
b) Estimati valoarea medie a timpului in secunde de procesare a emailului
c) Estimati probabilitatea ca emailul sa fie procesat in cel mult 4 secunde.
%}

%Subpunctul a)
m = 1;
sigma = 1;
probabilitateTeoretica = normcdf(1.5, m, sigma) - normcdf(-1.5, m, sigma)

%Subpunctul b)
nr_simulari = 1000;
timpi = [];
for i = 1 : nr_simulari
  t1 = abs(normrnd(m, sigma));
  if t1 > 2
    t2 = exprnd(2);
    timpi = [timpi, t1 + t2];
  else
    timpi = [timpi, t1];
  endif
endfor

probabilitateB = mean(timpi)

%Subpunctul c)
probabilitateC = mean(timpi <= 4)