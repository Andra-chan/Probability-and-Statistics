%{
Un email este trimis catre un server S1, S1 proceseaza un email
in t1 secunde, unde t1 are distributia exponentiala cu media 4 secunde.
Daca au trecut 4 secunde, iar emailul nu a fost procesat de serverul S1
pana in acest moment, atunci emailul este redirectionat instant catre un al
doilea server S2 care proceseaza un email in t2 secunde, unde t2 are distributia
uniforma pe intervalul [1, 3].

a) Afisati probabilitatea teoretica pentru ca emailul sa fie 
procesat in cel mult 3 secunde
b) Estimati valoarea medie a timpului in secunde de procesare a emailului
c) Estimati probabilitatea ca emailul sa fie procesat in cel mult 4 secunde
%}

%Subpunctul a)
media = 4;

probabilitateTeoretica = expcdf(3, media)

%Subpunctul b)
nr_simulari = 1000;

timpi = [];
countC = 0;

for i = 1 : nr_simulari
   t1 = exprnd(media);
   if t1 <= 4 
     timpi = [timpi, t1];
     countC++;
   else
     t2 = unifrnd(1, 3);
     timpi = [timpi, t1 + t2];
   endif
endfor

valoareMedieTimpi = mean(timpi)

%Subpunctul c)
probabilitateC = countC / nr_simulari