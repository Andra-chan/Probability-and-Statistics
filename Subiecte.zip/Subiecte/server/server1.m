%{
Un email este trimis aleator catre unul din 4 servere
disponibil astfel:
cu probabilitatea i/10 catre serverul s_i care apoi
proceseaza emailul in t_i secunde, unde t_i are distributia exponentiala
cu media i secunde, pentru i apartine {1, 2, 3, 4}

a) Afisati probabilitatea teoretica pentru ca emailul
sa fie procesat de serverul s_3 sau s_4
b) Estimati valoare medie a timpului in secunde
de procesare a emailului
c) Estimati probabilitatea ca emailul sa fie procesat in cel putin 3 secunde.
%}

%Subpunctu a)

% probabilitatea sa fie procesat de S1 = 1/10
% probabilitatea sa fie procesat de S2 = 2/10
% probabilitatea sa fie procesat de S3 = 3/10
% probabilitatea sa fie procesat de S4 = 4/10

disp('Probabilitatea teoretica = 0.7');

%Subpunctul b)
nr_simulari = 1000;
servere = [1, 2, 3, 4];
timpi = [];

countTimp = 0;

for i = 1 : nr_simulari
  server = randsample(servere, 1, replacement = true, [1/10, 2/10, 3/10, 4/10]);
  timp = exprnd(server);
  timpi = [timpi, timp];
  
  if timp >= 3
    countTimp++;
  endif
endfor

valoareMedieTimp = mean(timpi)

%Subpunctul c)
probabilitate = countTimp / nr_simulari

  
  