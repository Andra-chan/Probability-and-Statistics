% lab 1, ex. 2
v = [2 3 5 7];
nchoosek(v, 2)