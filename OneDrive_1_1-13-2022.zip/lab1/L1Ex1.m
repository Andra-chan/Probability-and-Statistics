%lab 1, ex. 1
perms 'word'